import './ReportModal.css';

function ReportModal({ isOpen, onClose, onGenerate }) {
  if (!isOpen) return null;

  return (
    <div className="report-modal-backdrop" onMouseDown={onClose}>
      <div
        className="report-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="report-modal-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="report-modal-header">
          <h2 id="report-modal-title">Формирование отчёта</h2>
          <button type="button" className="report-close" onClick={onClose} aria-label="Закрыть">
            ×
          </button>
        </div>

        <p className="report-modal-text">
          На этом этапе окно готово как интерфейс. Генерацию PDF подключим после настройки jsPDF и html2canvas.
        </p>

        <div className="report-modal-actions">
          <button type="button" className="report-secondary" onClick={onClose}>
            Отмена
          </button>
          <button type="button" className="report-primary" onClick={onGenerate}>
            Сформировать
          </button>
        </div>
      </div>
    </div>
  );
}

export default ReportModal;
