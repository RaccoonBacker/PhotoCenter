import { Link, useNavigate } from 'react-router-dom';
import './Header.css';

function Header() {
  const navigate = useNavigate();

  const handleLogoClick = () => {
    navigate('/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleHomeClick = () => {
    navigate('/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAboutClick = () => {
    navigate('/');
    setTimeout(() => {
      const el = document.getElementById('about');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <header className="header">
      <div className="header-container">
        {/* Логотип */}
        <div className="header-logo" onClick={handleLogoClick}>
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
            <circle cx="12" cy="12" r="4" fill="currentColor"/>
          </svg>
          <span>Фотоцентр</span>
        </div>

        {/* Навигация */}
        <nav className="header-nav">
          <Link to="/" className="header-link" onClick={handleHomeClick}>
            Главная
          </Link>
          <Link to="/services" className="header-link">
            Услуги
          </Link>
          <Link to="/products" className="header-link">
            Товары
          </Link>
          <a href="#about" className="header-link" onClick={handleAboutClick}>
            О нас
          </a>
        </nav>

        {/* Правая часть */}
        <div className="header-right">
          <Link to="/cart" className="header-cart">
            🛒 <span className="cart-count">0</span>
          </Link>
          <button className="header-login-btn">Войти</button>
        </div>
      </div>
    </header>
  );
}

export default Header;