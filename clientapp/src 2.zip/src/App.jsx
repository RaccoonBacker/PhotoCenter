import {
  BrowserRouter,
  Routes,
  Route,
} from 'react-router-dom';

import Header from './components/Header';
import Footer from './components/Footer';

import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import ProductsPage from './pages/ProductsPage';
import CartPage from './pages/CartPage';
import ProfilePage from './pages/ProfilePage';

import './styles/theme.css';

function CheckoutPage() {
  return (
    <div
      style={{
        minHeight: '60vh',
        padding: '80px 24px',
        textAlign: 'center',
      }}
    >
      <h1>Оформление заказа</h1>
      <p>
        Страница находится в разработке.
      </p>
    </div>
  );
}

function AdminPage() {
  return (
    <div
      style={{
        minHeight: '60vh',
        padding: '80px 24px',
        textAlign: 'center',
      }}
    >
      <h1>Панель управления</h1>
      <p>
        Административная панель находится в разработке.
      </p>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Header />

      <main
        style={{
          minHeight: '60vh',
          flex: 1,
        }}
      >
        <Routes>
          {/* Главная */}
          <Route
            path="/"
            element={<HomePage />}
          />

          {/* Каталог */}
          <Route
            path="/services"
            element={<ServicesPage />}
          />

          <Route
            path="/products"
            element={<ProductsPage />}
          />

          {/* Корзина */}
          <Route
            path="/cart"
            element={<CartPage />}
          />

          {/* Оформление заказа */}
          <Route
            path="/checkout"
            element={<CheckoutPage />}
          />

          {/* Личный кабинет */}
          <Route
            path="/profile"
            element={<ProfilePage />}
          />

          {/* Админ-панель */}
          <Route
            path="/admin"
            element={<AdminPage />}
          />

          {/* 404 */}
          <Route
            path="*"
            element={
              <div
                style={{
                  minHeight: '60vh',
                  padding: '80px 24px',
                  textAlign: 'center',
                }}
              >
                <h1>404</h1>
                <p>
                  Страница не найдена.
                </p>
              </div>
            }
          />
        </Routes>
      </main>

      <Footer />
    </BrowserRouter>
  );
}

export default App;