import { useEffect, useState } from 'react';
import './AuthModal.css';

function AuthModal({
  isOpen,
  onClose,
  onAuthSuccess,
}) {
  const [mode, setMode] = useState('login');

  const [loginData, setLoginData] = useState({
    login: '',
    password: '',
  });

  const [registerData, setRegisterData] = useState({
    login: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    phone: '',
    email: '',
  });

  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setError('');
      return;
    }

    setMode('login');
    setError('');
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) {
      return undefined;
    }

    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) {
    return null;
  }

  const handleOverlayClick = (event) => {
    if (event.target === event.currentTarget) {
      onClose();
    }
  };

  const handleLoginChange = (event) => {
    const { name, value } = event.target;

    setLoginData((previous) => ({
      ...previous,
      [name]: value,
    }));

    setError('');
  };

  const handleRegisterChange = (event) => {
    const { name, value } = event.target;

    setRegisterData((previous) => ({
      ...previous,
      [name]: value,
    }));

    setError('');
  };

  const handleLoginSubmit = (event) => {
    event.preventDefault();

    if (!loginData.login.trim()) {
      setError('Введите логин.');
      return;
    }

    if (!loginData.password) {
      setError('Введите пароль.');
      return;
    }

    /*
     * ВАЖНО:
     * Пока AuthController и JWT не подключены.
     *
     * В дальнейшем здесь будет примерно:
     *
     * const response = await fetch('/api/auth/login', {...});
     * const data = await response.json();
     * localStorage.setItem('token', data.token);
     *
     * Сейчас создаём временного пользователя,
     * чтобы интерфейс Header можно было проверить.
     */

    const temporaryUser = {
      name: loginData.login,
      role: 'Client',
    };

    onAuthSuccess(temporaryUser);
  };

  const handleRegisterSubmit = (event) => {
    event.preventDefault();

    if (!registerData.login.trim()) {
      setError('Введите логин.');
      return;
    }

    if (!registerData.fullName.trim()) {
      setError('Введите ФИО.');
      return;
    }

    if (!registerData.email.trim()) {
      setError('Введите email.');
      return;
    }

    if (!registerData.password) {
      setError('Введите пароль.');
      return;
    }

    if (registerData.password.length < 6) {
      setError('Пароль должен содержать минимум 6 символов.');
      return;
    }

    if (
      registerData.password !==
      registerData.confirmPassword
    ) {
      setError('Пароли не совпадают.');
      return;
    }

    /*
     * Здесь позже будет запрос:
     *
     * POST /api/auth/register
     */

    const temporaryUser = {
      name: registerData.fullName,
      role: 'Client',
    };

    onAuthSuccess(temporaryUser);
  };

  return (
    <div
      className="auth-modal-overlay"
      onMouseDown={handleOverlayClick}
      role="presentation"
    >
      <div
        className="auth-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-title"
      >
        {/* Заголовок */}
        <div className="auth-modal-header">
          <div>
            <h2 id="auth-modal-title">
              {mode === 'login'
                ? 'Вход'
                : 'Регистрация'}
            </h2>

            <p>
              {mode === 'login'
                ? 'Войдите в личный кабинет'
                : 'Создайте аккаунт в Фотоцентре'}
            </p>
          </div>

          <button
            type="button"
            className="auth-modal-close"
            onClick={onClose}
            aria-label="Закрыть"
          >
            ×
          </button>
        </div>

        {/* Переключатель */}
        <div className="auth-tabs">
          <button
            type="button"
            className={
              mode === 'login'
                ? 'auth-tab active'
                : 'auth-tab'
            }
            onClick={() => {
              setMode('login');
              setError('');
            }}
          >
            Войти
          </button>

          <button
            type="button"
            className={
              mode === 'register'
                ? 'auth-tab active'
                : 'auth-tab'
            }
            onClick={() => {
              setMode('register');
              setError('');
            }}
          >
            Регистрация
          </button>
        </div>

        {/* Ошибка */}
        {error && (
          <div className="auth-error">
            {error}
          </div>
        )}

        {/* Вход */}
        {mode === 'login' && (
          <form
            className="auth-form"
            onSubmit={handleLoginSubmit}
          >
            <div className="auth-field">
              <label htmlFor="login">
                Логин
              </label>

              <input
                id="login"
                name="login"
                type="text"
                value={loginData.login}
                onChange={handleLoginChange}
                placeholder="Введите логин"
                autoComplete="username"
              />
            </div>

            <div className="auth-field">
              <label htmlFor="login-password">
                Пароль
              </label>

              <input
                id="login-password"
                name="password"
                type="password"
                value={loginData.password}
                onChange={handleLoginChange}
                placeholder="Введите пароль"
                autoComplete="current-password"
              />
            </div>

            <button
              type="submit"
              className="auth-submit-btn"
            >
              Войти
            </button>
          </form>
        )}

        {/* Регистрация */}
        {mode === 'register' && (
          <form
            className="auth-form"
            onSubmit={handleRegisterSubmit}
          >
            <div className="auth-field">
              <label htmlFor="register-full-name">
                ФИО
              </label>

              <input
                id="register-full-name"
                name="fullName"
                type="text"
                value={registerData.fullName}
                onChange={handleRegisterChange}
                placeholder="Иванов Иван Иванович"
                autoComplete="name"
              />
            </div>

            <div className="auth-field">
              <label htmlFor="register-login">
                Логин
              </label>

              <input
                id="register-login"
                name="login"
                type="text"
                value={registerData.login}
                onChange={handleRegisterChange}
                placeholder="Введите логин"
                autoComplete="username"
              />
            </div>

            <div className="auth-field">
              <label htmlFor="register-email">
                Email
              </label>

              <input
                id="register-email"
                name="email"
                type="email"
                value={registerData.email}
                onChange={handleRegisterChange}
                placeholder="example@mail.ru"
                autoComplete="email"
              />
            </div>

            <div className="auth-field">
              <label htmlFor="register-phone">
                Телефон
              </label>

              <input
                id="register-phone"
                name="phone"
                type="tel"
                value={registerData.phone}
                onChange={handleRegisterChange}
                placeholder="+7 (999) 123-45-67"
                autoComplete="tel"
              />
            </div>

            <div className="auth-field">
              <label htmlFor="register-password">
                Пароль
              </label>

              <input
                id="register-password"
                name="password"
                type="password"
                value={registerData.password}
                onChange={handleRegisterChange}
                placeholder="Минимум 6 символов"
                autoComplete="new-password"
              />
            </div>

            <div className="auth-field">
              <label htmlFor="register-confirm-password">
                Повторите пароль
              </label>

              <input
                id="register-confirm-password"
                name="confirmPassword"
                type="password"
                value={registerData.confirmPassword}
                onChange={handleRegisterChange}
                placeholder="Повторите пароль"
                autoComplete="new-password"
              />
            </div>

            <button
              type="submit"
              className="auth-submit-btn"
            >
              Зарегистрироваться
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

export default AuthModal;