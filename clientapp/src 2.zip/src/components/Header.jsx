import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import AuthModal from './AuthModal';
import './Header.css';

function Header() {
  const navigate = useNavigate();
  const location = useLocation();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Пока авторизация не подключена к JWT.
  // Позже эти данные будут браться из localStorage/JWT.
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);

  const cartCount = 0;

  const isAdmin = user?.role === 'Admin';
  const isEmployee = user?.role === 'Employee';

  const isHomeActive = location.pathname === '/';
  const isServicesActive = location.pathname === '/services';
  const isProductsActive = location.pathname === '/products';
  const isProfileActive = location.pathname === '/profile';

  const closeMenus = () => {
    setIsMobileMenuOpen(false);
    setIsProfileOpen(false);
  };

  const handleLogoClick = () => {
    closeMenus();

    if (location.pathname === '/') {
      window.scrollTo({
        top: 0,
        behavior: 'smooth',
      });
    } else {
      navigate('/');
    }
  };

  const handleHomeClick = (event) => {
    event.preventDefault();
    closeMenus();

    if (location.pathname === '/') {
      window.scrollTo({
        top: 0,
        behavior: 'smooth',
      });
    } else {
      navigate('/');
    }
  };

  const handleAboutClick = (event) => {
    event.preventDefault();
    closeMenus();

    if (location.pathname !== '/') {
      navigate('/');

      setTimeout(() => {
        const element = document.getElementById('about');

        if (element) {
          element.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
        }
      }, 100);
    } else {
      const element = document.getElementById('about');

      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
        });
      }
    }
  };

  const handleAuthSuccess = (userData) => {
    setIsAuthenticated(true);
    setUser(userData || null);
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setIsProfileOpen(false);
    setIsMobileMenuOpen(false);

    // Пока JWT не подключён.
    // Позже здесь будет localStorage.removeItem('token').
  };

  const openAuthModal = () => {
    closeMenus();
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsProfileOpen(false);
  }, [location.pathname]);

  return (
    <>
      <header className="header">
        <div className="header-container">

          {/* Логотип */}
          <button
            type="button"
            className="header-logo"
            onClick={handleLogoClick}
            aria-label="Перейти на главную"
          >
            <svg
              className="header-logo-icon"
              width="34"
              height="34"
              viewBox="0 0 24 24"
              fill="none"
              aria-hidden="true"
            >
              <circle
                cx="12"
                cy="12"
                r="9.5"
                stroke="currentColor"
                strokeWidth="1.8"
              />
              <circle
                cx="12"
                cy="12"
                r="4"
                fill="currentColor"
              />
              <circle
                cx="17.5"
                cy="6.5"
                r="1.2"
                fill="currentColor"
              />
            </svg>

            <span>Фотоцентр</span>
          </button>

          {/* Основная навигация */}
          <nav
            className={`header-nav ${
              isMobileMenuOpen ? 'header-nav-open' : ''
            }`}
            aria-label="Основная навигация"
          >
            <a
              href="/"
              className={`header-link ${
                isHomeActive ? 'active' : ''
              }`}
              onClick={handleHomeClick}
            >
              Главная
            </a>

            <Link
              to="/services"
              className={`header-link ${
                isServicesActive ? 'active' : ''
              }`}
              onClick={closeMenus}
            >
              Услуги
            </Link>

            <Link
              to="/products"
              className={`header-link ${
                isProductsActive ? 'active' : ''
              }`}
              onClick={closeMenus}
            >
              Товары
            </Link>

            <a
              href="/#about"
              className={`header-link ${
                isHomeActive && window.location.hash === '#about'
                  ? 'active'
                  : ''
              }`}
              onClick={handleAboutClick}
            >
              О нас
            </a>

            {/* Управление — только для администратора */}
            {isAdmin && (
              <Link
                to="/admin"
                className={`header-link ${
                  location.pathname === '/admin' ? 'active' : ''
                }`}
                onClick={closeMenus}
              >
                Управление
              </Link>
            )}
          </nav>

          {/* Правая часть */}
          <div className="header-right">

            {/* Корзина */}
            <Link
              to="/cart"
              className={`header-cart ${
                location.pathname === '/cart' ? 'active' : ''
              }`}
              onClick={closeMenus}
              aria-label={`Корзина, товаров: ${cartCount}`}
            >
              <span className="cart-icon" aria-hidden="true">
                <svg
                  width="23"
                  height="23"
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <path
                    d="M3 4H5L7.2 14.2C7.42 15.25 8.35 16 9.42 16H17.4C18.38 16 19.24 15.37 19.54 14.43L21 9H6"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <circle
                    cx="9"
                    cy="20"
                    r="1.4"
                    fill="currentColor"
                  />
                  <circle
                    cx="18"
                    cy="20"
                    r="1.4"
                    fill="currentColor"
                  />
                </svg>
              </span>

              <span className="cart-count">
                {cartCount}
              </span>
            </Link>

            {/* Профиль */}
            {isAuthenticated && (
              <div className="profile-menu-wrapper">
                <button
                  type="button"
                  className={`profile-button ${
                    isProfileActive ? 'active' : ''
                  }`}
                  onClick={() => setIsProfileOpen((value) => !value)}
                  aria-expanded={isProfileOpen}
                >
                  <span>
                    {user?.name || 'Профиль'}
                  </span>

                  <span
                    className={`profile-arrow ${
                      isProfileOpen ? 'profile-arrow-open' : ''
                    }`}
                  >
                    ▼
                  </span>
                </button>

                {isProfileOpen && (
                  <div className="profile-dropdown">

                    <Link
                      to="/profile"
                      onClick={closeMenus}
                    >
                      Профиль
                    </Link>

                    <Link
                      to="/profile"
                      onClick={closeMenus}
                    >
                      Мои заказы
                    </Link>

                    <Link
                      to="/profile"
                      onClick={closeMenus}
                    >
                      Отзывы
                    </Link>

                    <Link
                      to="/cart"
                      onClick={closeMenus}
                    >
                      Корзина
                    </Link>

                    {(isEmployee || isAdmin) && (
                      <>
                        <div className="profile-dropdown-divider" />

                        <Link
                          to="/profile"
                          onClick={closeMenus}
                        >
                          Мои задачи
                        </Link>

                        <Link
                          to="/profile"
                          onClick={closeMenus}
                        >
                          Управление заказами
                        </Link>

                        <Link
                          to="/profile"
                          onClick={closeMenus}
                        >
                          Материалы
                        </Link>
                      </>
                    )}

                    <div className="profile-dropdown-divider" />

                    <button
                      type="button"
                      className="profile-logout"
                      onClick={handleLogout}
                    >
                      Выйти
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Войти / имя */}
            {!isAuthenticated && (
              <button
                type="button"
                className="header-login-btn"
                onClick={openAuthModal}
              >
                Войти
              </button>
            )}

            {/* Мобильная кнопка */}
            <button
              type="button"
              className={`header-burger ${
                isMobileMenuOpen ? 'header-burger-open' : ''
              }`}
              onClick={() =>
                setIsMobileMenuOpen((value) => !value)
              }
              aria-label={
                isMobileMenuOpen
                  ? 'Закрыть меню'
                  : 'Открыть меню'
              }
              aria-expanded={isMobileMenuOpen}
            >
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
      </header>

      {/* Модальное окно авторизации */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={closeAuthModal}
        onAuthSuccess={handleAuthSuccess}
      />
    </>
  );
}

export default Header;