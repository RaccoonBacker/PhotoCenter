﻿using System;
using System.Linq;
using System.Web.Http;
using System.Web.Mvc;
using PhotoCenterWeb.Models;

namespace PhotoCenterWeb.Controllers
{
    [RoutePrefix("api/orders")]
    public class OrdersApiController : ApiController
    {
        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll(
            string status = null,
            DateTime? dateFrom = null,
            DateTime? dateTo = null,
            int limit = 100)
        {
            using (var context = new PhotoCenterContext())
            {
                var query = context.Orders.AsQueryable();

                if (!string.IsNullOrEmpty(status))
                    query = query.Where(o => o.Status == status);

                if (dateFrom.HasValue)
                    query = query.Where(o => o.CreatedDate >= dateFrom.Value);

                if (dateTo.HasValue)
                    query = query.Where(o => o.CreatedDate <= dateTo.Value);

                var orders = query
                    .OrderByDescending(o => o.CreatedDate)
                    .Take(limit)
                    .ToList()
                    .Select(o => new
                    {
                        o.ID,
                        ClientName = o.Client != null
                            ? o.Client.LastName + " " + o.Client.FirstName
                            : "",
                        EmployeeName = o.Employee != null
                            ? o.Employee.LastName + " " + o.Employee.FirstName
                            : "",
                        o.CreatedDate,
                        o.Status,
                        o.TotalPrice
                    })
                    .ToList();

                return Ok(orders);
            }
        }

        [HttpPut]
        [Route("{id}")]
        public IHttpActionResult Update(int id, [FromBody] OrderUpdateDto dto)
        {
            using (var context = new PhotoCenterContext())
            {
                var order = context.Orders.Find(id);
                if (order == null) return NotFound();

                if (!string.IsNullOrEmpty(dto.Status)) order.Status = dto.Status;
                if (dto.EmployeeID.HasValue) order.EmployeeID = dto.EmployeeID;

                context.SaveChanges();
                return Ok();
            }
        }

        [HttpDelete]
        [Route("{id}")]
        public IHttpActionResult Delete(int id)
        {
            using (var context = new PhotoCenterContext())
            {
                var order = context.Orders.Find(id);
                if (order == null) return NotFound();

                context.Orders.Remove(order);
                context.SaveChanges();
                return Ok();
            }
        }
    }

    public class OrderUpdateDto
    {
        public string Status { get; set; }
        public int? EmployeeID { get; set; }
    }
}