﻿using System.Linq;
using System.Web.Http;
using System.Web.Mvc;
using PhotoCenterWeb.Models;

namespace PhotoCenterWeb.Controllers
{
    [RoutePrefix("api/users")]
    public class UsersApiController : ApiController
    {
        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAll(
            string role = null,
            bool? isActive = null,
            int limit = 100)
        {
            using (var context = new PhotoCenterContext())
            {
                var query = context.Users.AsQueryable();

                if (!string.IsNullOrEmpty(role))
                    query = query.Where(u => u.Role == role);

                if (isActive.HasValue)
                    query = query.Where(u => u.IsActive == isActive.Value);

                var users = query
                    .Take(limit)
                    .ToList()
                    .Select(u => new
                    {
                        u.ID,
                        u.Login,
                        u.Role,
                        u.IsActive,
                        FirstName = u.Client != null ? u.Client.FirstName :
                                    u.Employee != null ? u.Employee.FirstName : "",
                        LastName = u.Client != null ? u.Client.LastName :
                                   u.Employee != null ? u.Employee.LastName : "",
                        Phone = u.Client != null ? u.Client.Phone : "",
                        Email = u.Client != null ? u.Client.Email : ""
                    })
                    .ToList();

                return Ok(users);
            }
        }

        [HttpPut]
        [Route("{id}")]
        public IHttpActionResult Update(int id, [FromBody] UserUpdateDto dto)
        {
            using (var context = new PhotoCenterContext())
            {
                var user = context.Users.Find(id);
                if (user == null) return NotFound();

                if (!string.IsNullOrEmpty(dto.Login)) user.Login = dto.Login;
                if (!string.IsNullOrEmpty(dto.Role)) user.Role = dto.Role;
                if (dto.IsActive.HasValue) user.IsActive = dto.IsActive.Value;

                context.SaveChanges();
                return Ok();
            }
        }

        [HttpDelete]
        [Route("{id}")]
        public IHttpActionResult Delete(int id)
        {
            using (var context = new PhotoCenterContext())
            {
                var user = context.Users.Find(id);
                if (user == null) return NotFound();

                context.Users.Remove(user);
                context.SaveChanges();
                return Ok();
            }
        }
    }

    public class UserUpdateDto
    {
        public string Login { get; set; }
        public string Role { get; set; }
        public bool? IsActive { get; set; }
    }
}